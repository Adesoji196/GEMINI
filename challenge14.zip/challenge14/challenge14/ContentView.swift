//
//  ContentView.swift
//  challenge14
//
//  Created by Turma02-1 on 03/11/26.
//

import SwiftUI
import FirebaseAI

struct ContentView: View {
    
    let model = FirebaseAI.firebaseAI(backend: .googleAI()).generativeModel(modelName:  "gemini-3.1-flash-lite")
    
    @State var prompt: String = ""
    @State var iaResponse: String = ""
    @State var isLoading: Bool = false
    func sendMessage() {
        let userPrompt = prompt
        prompt = ""
        isLoading = true
        iaResponse = ""
        
        Task {
            do {
                let response = try await model.generateContent(userPrompt)
                iaResponse = response.text ?? "Sem resposta..."
            } catch {
                iaResponse = "Erro: \(error.localizedDescription)"
            }
            isLoading = false
            }
    }
    var body: some View {
        VStack {
            TextField("Type here...", text: $prompt)
                .multilineTextAlignment(.center)
                .padding()
                .border(.black)
            
            Button("SEND") {
                sendMessage()
            }
            ScrollView {
                Text(iaResponse)
            }
        }
        .padding()
    }
    //
}

#Preview {
    ContentView()
}
