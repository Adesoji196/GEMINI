//
//  challenge14App.swift
//  challenge14
//
//  Created by Turma02-1 on 03/11/26.
//

import SwiftUI
import Firebase

@main
struct challenge14App: App {
    init() {
        let provider = AppCheckDebugProviderFactory()
        AppCheck.setAppCheckProviderFactory(provider)
        FirebaseApp.configure()
        
    }
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
